﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication27.Data
{
    public class SessionStateClass
    {
        public string str { get; set; }
    }
}
