﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication29.Data
{
    public class Class
    {
        public string msg { get; set; } = "Empty";
    }
}
