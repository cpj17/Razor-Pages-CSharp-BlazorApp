﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication22.Pages;

namespace WebApplication22.Data
{
    public class ClsData
    {
        public string BE_ID { get; set; } = "BSPL";

        public string BECUR_ID { get; set; }

        public string NAME { get; set; }

        public decimal DEFAULT_EXRATE { get; set; }

        public string SYMBOL { get; set; }

        public string DELMARK { get; set; }

        public string GW_STATUS { get; set; }

        public string CREATED_AT { get; set; }

        public string CREATED_BY { get; set; }

        public DateTime CREATED_ON { get; set; }

        public string MODIFIED_AT { get; set; }

        public string MODIFIED_BY { get; set; }

        public DateTime? MODIFIED_ON { get; set; }
        public string DML_INDICATOR { get; set; }
    }
}
