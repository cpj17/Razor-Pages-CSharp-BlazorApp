﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication22.Data
{
    public class Clslistscs
    {
        public string stringExpression { get; set; }

        public string stringOrderby { get; set; }

        public int intRecordFrom { get; set; }

        public int intRecordTo { get; set; }
    }
}
