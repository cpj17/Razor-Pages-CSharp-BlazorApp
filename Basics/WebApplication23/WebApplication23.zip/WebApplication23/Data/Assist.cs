﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication23.Data
{
    public class Assist
    {
        public string msg { get; set; }
    }
}
