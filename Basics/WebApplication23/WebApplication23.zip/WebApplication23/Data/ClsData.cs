﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WebApplication23.Data
{
    public class ClsData
    {
        [Required]
        [StringLength(10, ErrorMessage = "ID Length Should Be Have Minimun 3 Maximum 10.",MinimumLength =3)]
        public string BECUR_ID { get; set; }
        
        [Required]
        [StringLength(10, ErrorMessage = "Name Length Should Be Have Minimun 3 Maximum 10.", MinimumLength = 3)]
        public string NAME { get; set; }

        [StringLength(10, ErrorMessage = "Symbol Length Should Be Have Minimun 3 Maximum 10.", MinimumLength = 3)]
        public string SYMBOL { get; set; }

        [Range(0, 100, ErrorMessage = "X-rate range between (1-100).")]
        public decimal DEFAULT_EXRATE { get; set; }
    }
}
