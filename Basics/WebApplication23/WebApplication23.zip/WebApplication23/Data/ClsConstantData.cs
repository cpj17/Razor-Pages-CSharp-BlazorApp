﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication23.Data
{
    public class ClsConstantData
    {
        public string BE_ID { get; set; } = "BSPL";

        public string CREATED_AT { get; set; } = Environment.MachineName;

        public string DELMARK { get; set; } = "N";

        public string GW_STATUS { get; set; } = "UNSEND";

        public string CREATED_BY { get; set; } = "PRAVEEN";

        public DateTime CREATED_ON { get; set; } = DateTime.Now;

        public string MODIFIED_AT { get; set; } = Environment.MachineName;

        public string MODIFIED_BY { get; set; } = "PRAVEEN";

        public DateTime? MODIFIED_ON { get; set; } = DateTime.Now;
        public string DML_INDICATOR { get; set; } = "I";
    }
}
