﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication32.Data
{
    public class Class2
    {
        public string str3 { get; set; }
        public string str4 { get; set; }
    }
}
