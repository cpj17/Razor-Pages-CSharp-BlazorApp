﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication32.Data
{
    public class SessionState
    {
        public Int32 from { get; set; }
        public Int32 to { get; set; } = 1;
    }
}
