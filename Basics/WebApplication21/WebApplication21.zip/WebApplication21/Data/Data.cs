﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication21
{
    public class ClsData
    {
        public string SYMBOL { get; set; } = "";
        public float DEFAULT_EXRATE { get; set; }
        public string NAME { get; set; }
        public string BECUR_ID { get; set; }
        public string BE_ID { get; set; }
    }
}
