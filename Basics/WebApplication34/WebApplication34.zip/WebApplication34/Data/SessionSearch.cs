﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using Usersetting_And_ListData;

namespace WebApplication34.Data
{
    public class SessionSearch
    {
        public bool SessionSearch_Flag { get; set; } = false;
        public bool SessionSearch_Flag2 { get; set; } = false;

        public DataSet SessionDataSetResult { get; set; }

        public UsersettingCls[] SessionUserSetting { get; set; }
    }
}
