﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication34.Data
{
    public class SessionState
    {
        public string SessionAPIUrl { get; set; }

        public string SessionAPIUrlLevel2 { get; set; }

        public string SessionAPIUrlLevel3 { get; set; }

        public string SessionFormId { get; set; }

        public string SessionFormPath { get; set; } = "UserSetting/";

        public string SessionFormLevel { get; set; } = "LEVEL11";

        public string SessionFormName { get; set; }

        public string SessionAction { get; set; }

        public string SessionActionPageUrl { get; set; }

        public string SessionPrimaryKey { get; set; }

        public string SessionPageFrom { get; set; } = "/Collaboration";

        public string SessionPageFromMain { get; set; } = "/Collaboration";

        public string SessionKey1 { get; set; }

        public Int32 SessionCurrentPgNo { get; set; } = 1;

        public Int32 SessionRecordFrom { get; set; } = 0;

        public Int32 SessionIteration { get; set; } = 1;

        public Int32 SessionRowCount { get; set; } = 1;

        public Int32 SessionRecordTo { get; set; }

        public string SessionExpression { get; set; } = "";

        public string SessionKeyForSearch { get; set; }

        public string SessionKeyForSearch2 { get; set; }

        public string SessionWordToSearch { get; set; } = "";

        public string SessionWordToSearch2 { get; set; } = "";

        public string SessionSelectedCol_ToSearch { get; set; }

        public string SessionSelectedCol_ToSearch2 { get; set; }

        public string SessionConditional_OP { get; set; } = "LIKE";

        public string SessionConditional_OP2 { get; set; } = "LIKE";

        public bool SessionisShow_2nd_Search { get; set; } = false;

        public string SessionCon_4_Join { get; set; } = "AND";
    }
}
