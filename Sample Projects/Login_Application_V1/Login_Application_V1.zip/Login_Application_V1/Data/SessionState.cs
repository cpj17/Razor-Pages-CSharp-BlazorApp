﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login_Application_V1.Data
{
    public class SessionState
    {
        public string SessionUsername { get; set; }

        public string SessionPassword { get; set; }

        public string SessionStatus { get; set; }
    }
}
