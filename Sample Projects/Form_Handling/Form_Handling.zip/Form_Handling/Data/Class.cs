﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Form_Handling.Data
{
    public class Class
    {
        [Required]
        public string str1 { get; set; }
        [Required]
        public string str2 { get; set; }
        [Required]
        public string str3 { get; set; }
    }
}
