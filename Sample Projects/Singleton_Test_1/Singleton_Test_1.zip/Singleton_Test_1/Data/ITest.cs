﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Singleton_Test_1.Data
{
    interface ITest
    {
        public string ifStr { get; set; }
    }
}
