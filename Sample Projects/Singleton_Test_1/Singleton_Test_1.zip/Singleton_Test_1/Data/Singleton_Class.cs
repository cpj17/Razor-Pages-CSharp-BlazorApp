﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Singleton_Test_1.Data
{
    class Singleton_Class
    {
        public string clsStr { get; private set; }
        protected string clsStr2 { get; private set; }

        public void Set(string str)
        {
            clsStr = str;
        }

        public string Get()
        {
            return clsStr;
        }
    }
}
