﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Attendance_Tracker.Data
{
    public class Variables
    {
        public string Device_ID_Enc { get; set; }
    }
}
