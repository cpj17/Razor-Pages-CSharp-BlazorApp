﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Blazor_Login_Page.Data
{
    public class clsLoginData
    {
        public string stringUserID { get; set; }
        public string stringPassword { get; set; }
        public string stringErrorDetails { get; set; }
    }
}
